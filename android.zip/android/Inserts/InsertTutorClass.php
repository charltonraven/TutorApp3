<?php
$db_name = "tutor3test";
$mysql_username = "root";
$mysql_password = "";
$server_name = "localhost";
$conn=mysqli_connect($server_name,$mysql_username,$mysql_password,$db_name) or die("Error".mysqli_error($conn));

$id=$_POST["id"];
$courseNumber=$_POST["courseNumber"];
$departAbbr=$_POST["departAbbr"];

if(mysqli_connect_error($conn)){
	echo "Failed to Connect to Database ".mysqli_connect_error();
}


$query="Select departID from Department where departAbbr='$departAbbr'" ;
$result=mysqli_query($conn,$query);
$row=mysqli_fetch_row($result);

#$departmentNum=str_replace(PHP_EOL,'',$row[0]);
$departmentNum=preg_replace('/\s+/', '', $row[0]); 

$insertQuery="Insert INTO tutor VALUES('$id','$courseNumber','$departmentNum');";
$result=mysqli_query($conn,$insertQuery);

echo "$departmentNum";


mysqli_close($conn);
?>