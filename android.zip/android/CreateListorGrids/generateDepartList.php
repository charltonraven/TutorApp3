<?php

$db_name = "tutor3test";
$mysql_username = "root";
$mysql_password = "";
$server_name = "localhost";
$conn=mysqli_connect($server_name,$mysql_username,$mysql_password,$db_name) or die("Error".mysqli_error($conn));
#$what=$_POST["what"];
$what="department";


if($what=="department"){
	$mysql_qryDepartment="select departName from department;";
	$result=mysqli_query($conn,$mysql_qryDepartment);
	while($row=mysqli_fetch_array($result)){
		$flag[]=$row;
	}
	print(json_encode($flag));	
}



mysqli_close($conn)


?>