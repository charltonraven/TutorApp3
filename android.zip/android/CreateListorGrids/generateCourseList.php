<?php

$db_name = "tutor3test";
$mysql_username = "root";
$mysql_password = "";
$server_name = "localhost";
$conn=mysqli_connect($server_name,$mysql_username,$mysql_password,$db_name) or die("Error".mysqli_error($conn));

$what=$_POST["who"];
$departName = $_POST["departName"];
/* $what="course";
$departName = "Computer Science"; */



if($what=="course"){
	$mysql_qryCourse= "Select department.departAbbr, course.courseNumber from course INNER JOIN department ON department.departID=course.departID WHERE department.departName='$departName';";
	$result=mysqli_query($conn,$mysql_qryCourse);
	while($row=mysqli_fetch_array($result)){
		$flag[]=$row;
	}
	print(json_encode($flag));
}


mysqli_close($conn)


?>