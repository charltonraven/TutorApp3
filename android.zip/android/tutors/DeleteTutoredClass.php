<?php
$db_name = "tutor3test";
$mysql_username = "root";
$mysql_password = "";
$server_name = "localhost";
$conn=mysqli_connect($server_name,$mysql_username,$mysql_password,$db_name) or die("Error".mysqli_error($conn));

$id=$_POST["id"];
$courseNumber=$_POST["courseNumber"];
$departAbbr=$_POST["departAbbr"];

/* $id="cwilliams2638";
$courseNumber="102";
$departAbbr="CHEM"; */

$query="Select departID from Department where departAbbr='$departAbbr'" ;
$result=mysqli_query($conn,$query);
$row=mysqli_fetch_row($result);
$departID=preg_replace('/\s+/', '', $row[0]); 


$test="DELETE from tutor WHERE studentID='$id' AND courseNumber='$courseNumber' AND departID='$departID';";
$DeleteQuery= mysqli_query($conn,"DELETE from tutor WHERE studentID='$id' AND courseNumber='$courseNumber' AND departID='$departID';" );
echo "Complete\n";
echo $test;

mysqli_close($conn)


?>